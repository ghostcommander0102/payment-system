<?php $__env->startSection('template_title'); ?>
    <?php echo e(trans('installer_messages.permissions.templateTitle')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <i class="fa fa-key fa-fw" aria-hidden="true"></i>
    <?php echo e(__('Verify Envato Purchase Code')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>

    <form method="post" action="<?php echo e(route('LaravelInstaller::codeVerifyProcess')); ?>" class="tabs-wrap">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

        <div class="form-group <?php echo e($errors->has('purchase_code') ? ' has-error ' : ''); ?>">
            <label for="purchase_code">
                <?php echo e(__('Purchase Code')); ?>

            </label>
            <input type="text" name="purchase_code" id="purchase_code" value="" placeholder="<?php echo e(__('Envato purchase code')); ?>" />
            <?php if($errors->has('purchase_code')): ?>
                <span class="error-block">
                            <i class="fa fa-fw fa-exclamation-triangle" aria-hidden="true"></i>
                    <?php echo e($errors->first('purchase_code')); ?>

                </span>
            <?php endif; ?>
        </div>
        <div class="buttons">
            <button class="button" type="submit">
                <?php echo e(__('Verify Code')); ?>

                <i class="fa fa-angle-right fa-fw" aria-hidden="true"></i>
            </button>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.installer.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/p2p-exchange-web/resources/views/vendor/installer/verify.blade.php ENDPATH**/ ?>