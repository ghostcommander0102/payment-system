<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12 mb-xl-0 mb-4">
            <div class="card cp-user-custom-card">
                <div class="card-body">
                    <div class="cp-user-buy-coin-content-area">
                        <div class="cp-user-coin-info">
                            <div class="row mt-4">
                                <div class="col-sm-12">
                                    <div class="cp-user-card-header-area">
                                        <div class="title">
                                            <h4 id="list_title"><a href="<?php echo e(route('marketPlace')); ?>"><?php echo e(__(' Offer ')); ?></a> -> <?php echo e($type_text); ?>  <a href="<?php echo e(route('userTradeProfile',$offer->user_id)); ?>"><?php echo e($offer->user->first_name.' '.$offer->user->last_name); ?></a></h4>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-4">
                                            <form action="<?php echo e(route('placeOrder')); ?>" method="POST" enctype="multipart/form-data"
                                                  id="buy_coin">
                                                <?php echo csrf_field(); ?>
                                            <div class="cp-user-card-header-area">
                                                <div class="title">
                                                    <h4 id="list_title"><?php echo e(__('Open Trade')); ?></h4>
                                                </div>
                                            </div>
                                            <div class="cp-user-payment-type">
                                                <input type="hidden" name="type" value="<?php echo e($type); ?>">
                                                <input type="hidden" name="offer_id" value="<?php echo e($offer->id); ?>">
                                                <h3><?php echo e(__('Trade Amount ')); ?> <span><?php echo e(number_format($offer->minimum_trade_size,2). ' '.$offer->currency); ?> <?php echo e(__(' to ')); ?> <?php echo e(number_format($offer->maximum_trade_size,2). ' '.$offer->currency); ?></span></h3>
                                                <label class="text-warning"><?php echo e($offer->currency); ?></label><input name="price" id="tradeprice" class="form-control" placeholder="">
                                                <br/>
                                                <span class="text-danger"><strong><?php echo e($errors->first('price')); ?></strong></span>
                                                <label class="text-warning"><?php echo e($offer->coin_type); ?></label><input name="amount" id="tradeamount" class="form-control" placeholder="">
                                                <span class="text-danger"><strong><?php echo e($errors->first('amount')); ?></strong></span>
                                            </div>
                                            <div class="cp-user-payment-type">
                                                <h3><?php echo e(__('Select Payment Method')); ?></h3>
                                                <?php if(isset($offer->payment($offer->id)[0])): ?>
                                                    <?php $__currentLoopData = $offer->payment($offer->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pmethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="form-group">
                                                            <?php if(is_accept_payment_method($pmethod->payment_method_id,$country)): ?>
                                                                <input type="radio"  <?php if(old('payment_id') == $pmethod->payment_method_id): ?> checked <?php endif; ?>  value="<?php echo e($pmethod->payment_method_id); ?>" id='<?php echo e("coin-option".$pmethod->payment_method_id); ?>' name="payment_id">
                                                                <label for='<?php echo e("coin-option".$pmethod->payment_method_id); ?>'><?php echo e($pmethod->payment_method->name); ?></label>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                <span class="text-danger"><strong><?php echo e($errors->first('payment_id')); ?></strong></span>
                                            </div>
                                            <div class="cp-user-payment-type">
                                                <h3><?php echo e(__('Send Message ')); ?> </h3>
                                                <textarea name="text_message" class="form-control" id="" cols="30" rows="10" placeholder="<?php echo e(__('Say hello,. Traders use encrypted messages to exchange payment details.')); ?>"><?php echo e(old('text_message')); ?></textarea>
                                            </div>
                                                <button id="buy_button" type="submit" class="mt-4 btn theme-btn"><?php echo e(__('Open Trade')); ?></button>
                                            <p class="mt-2">
                                                <span class="text-warning"><b><?php echo e(__('Note : ')); ?></b></span>
                                                <span class=""><?php echo e(__('Once you open a trade, messages are end-to-end encrypted so your privacy is protected. The only case where we can read your messages is if either party initiates a dispute. ')); ?></span>
                                            </p>

                                            </form>
                                        </div>
                                        <div class="col-xl-1"></div>
                                        <div class="col-xl-7">
                                            <div class="cp-user-card-header-area">
                                                <div class="title">
                                                    <h4 id="list_title"><?php echo e(__('You are the ')); ?><?php echo e($type == 'buy' ? __('Buyer') : __('Seller')); ?></h4>
                                                </div>
                                            </div>
                                            <div class="cp-user-payment-type available-payment-method-list">
                                                <h3><?php echo e(__('Available Payment Method')); ?> </h3>
                                                <?php if(isset($offer->payment($offer->id)[0])): ?>
                                                    <?php $__currentLoopData = $offer->payment($offer->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pmethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <ul>
                                                            <?php if(is_accept_payment_method($pmethod->payment_method_id,$country)): ?>
                                                                <li class="text-warning">
                                                                    <span><img src="<?php echo e($pmethod->payment_method->image); ?>" alt=""></span>
                                                                    <?php echo e($pmethod->payment_method->name); ?>

                                                                </li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                                <h3 class="mt-5 ">
                                                   <span class="text-center">
                                                       1 <?php echo e($offer->coin_type); ?> = <?php echo e(number_format($offer->coin_rate,2)); ?><?php echo e(' '.$offer->currency); ?>

                                                   </span>
                                                </h3>
                                                <p class="mt-1 ">
                                                    <?php echo e(__('The ')); ?> <?php echo e($type == 'buy' ? __('Buyer') : __('Seller')); ?> <?php echo e(__(' chose this price — only continue if you’re comfortable with it.')); ?>

                                                </p>
                                            </div>
                                            <div class="row">
                                                <div class="col-xl-4">
                                                    <div class="cp-user-card-header-area">
                                                        <div class="title">
                                                            <h4 id="list_title"><?php echo e(__('About the ')); ?><?php echo e($type == 'sell' ? __('Buyer') : __('Seller')); ?></h4>
                                                        </div>
                                                    </div>
                                                    <ul class="about-seller">
                                                        <li>
                                                            <a href="<?php echo e(route('userTradeProfile',$offer->user_id)); ?>"><?php echo e($offer->user->first_name.' '.$offer->user->last_name); ?></a>
                                                        </li>
                                                        <li><?php echo e(__('100% good feedback')); ?></li>
                                                        <li><?php echo e(__('Registered ')); ?> <?php echo e(date('M Y', strtotime($offer->user->created_at))); ?></li>
                                                        <li><?php echo e(count_trades($offer->user_id)); ?> <?php echo e(__(' trades')); ?> </li>
                                                    </ul>
                                                </div>
                                                <div class="col-xl-8">
                                                    <div class="cp-user-card-header-area">
                                                        <div class="title">
                                                            <h4 id="list_title"><?php echo e(__('Headline ')); ?></h4>
                                                        </div>
                                                    </div>
                                                    <p><?php echo e($offer->headline); ?></p>

                                                    <div class="cp-user-card-header-area">
                                                        <div class="title">
                                                            <h4 id="list_title"><?php echo e(__('Terms and Condition ')); ?></h4>
                                                        </div>
                                                    </div>
                                                    <p><?php echo e(isset($offer->terms) ? $offer->terms : '.....................................'); ?></p>

                                                    <div class="cp-user-card-header-area">
                                                        <div class="title">
                                                            <h4 id="list_title"><?php echo e(__('Trading Instruction')); ?></h4>
                                                        </div>
                                                    </div>
                                                    <p><?php echo e(isset($offer->instruction) ? $offer->instruction : '.....................................'); ?></p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    <script>
        (function($) {
            "use strict";

            function delay(callback, ms) {
                var timer = 0;
                return function () {
                    var context = this, args = arguments;
                    clearTimeout(timer);
                    timer = setTimeout(function () {
                        callback.apply(context, args);
                    }, ms || 0);
                };
            }

            function call_trade_coin_rate(amount, type, order_type, offer_id) {

                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('getTradeCoinRate')); ?>",
                    data: {
                        '_token': "<?php echo e(csrf_token()); ?>",
                        'amount': amount,
                        'type': type,
                        'order_type': order_type,
                        'offer_id': offer_id,
                    },
                    dataType: 'JSON',

                    success: function (data) {
                        $('#tradeamount').val(data.amount)
                        $('#tradeprice').val(data.price)
                    },
                    error: function () {

                    }
                });
            }

            $("#tradeamount").on('keyup', delay(function (e) {
                var amount = $('input[name=amount]').val();
                var type = 'same';
                var order_type = '<?php echo e($type); ?>';
                var offer_id = '<?php echo e($offer->id); ?>';

                call_trade_coin_rate(amount, type, order_type, offer_id);

            }, 500));

            $("#tradeprice").on('keyup', delay(function (e) {
                var amount = $('input[name=price]').val();
                var type = 'reverse';
                var order_type = '<?php echo e($type); ?>';
                var offer_id = '<?php echo e($offer->id); ?>';

                call_trade_coin_rate(amount, type, order_type, offer_id);

            }, 500));

        })(jQuery);
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master',[ 'menu'=>'marketplace'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/p2p-exchange-web/resources/views/user/marketplace/market/open_trade.blade.php ENDPATH**/ ?>