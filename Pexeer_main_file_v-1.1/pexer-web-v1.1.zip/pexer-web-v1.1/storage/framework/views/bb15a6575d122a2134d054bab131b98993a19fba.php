<?php if(isset($payment_methods[0])): ?>
    <?php $__currentLoopData = $payment_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($payment_method->payment_method_id); ?>"><?php echo e($payment_method->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/p2p-exchange-web/resources/views/user/marketplace/offer/country_payment_method.blade.php ENDPATH**/ ?>