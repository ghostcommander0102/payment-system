<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12 mb-xl-0 mb-4">
            <div class="card cp-user-custom-card">
                <div class="card-body">
                    <div class="cp-user-buy-coin-content-area">
                        <div class="cp-user-coin-info">
                            <div class="row mt-4">
                                <div class="col-sm-12">
                                    <div class="cp-user-card-header-area">
                                        <div class="title">
                                            <h4 id="list_title"><?php echo e(__('My Trade List')); ?></h4>
                                        </div>
                                    </div>
                                    <div class="cp-user-wallet-table table-responsive buy-table">
                                        <table class="table">
                                            <thead>
                                            <tr>
                                                <th><?php echo e(__('Date Opened')); ?></th>
                                                <th><?php echo e(__('Type')); ?></th>
                                                <th><?php echo e(__('Crypto')); ?></th>
                                                <th><?php echo e(__('Fees')); ?></th>
                                                <th><?php echo e(__('Amount')); ?></th>
                                                <th><?php echo e(__('Trade partner')); ?></th>
                                                <th><?php echo e(__('State')); ?></th>
                                                <th><?php echo e(__('Action')); ?></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php if(isset($items[0])): ?>
                                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e(date('d M y', strtotime($item->created_at))); ?></td>
                                                        <td>
                                                            <?php if($item->buyer_id == Auth::id()): ?>
                                                                <?php echo e(__('Buying')); ?>

                                                            <?php elseif($item->seller_id == Auth::id()): ?>
                                                                <?php echo e(__('Selling')); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($item->amount.' '.$item->coin_type); ?></td>
                                                        <td><?php echo e($item->fees.' '.$item->coin_type); ?></td>
                                                        <td><?php echo e($item->price.' '.$item->coin_type); ?></td>
                                                        <td>
                                                            <?php if($item->buyer_id == Auth::id()): ?>
                                                                <a href="<?php echo e(route('userTradeProfile',$item->seller_id)); ?>"> <?php echo e($item->seller->first_name.' '.$item->seller->last_name); ?> </a>
                                                            <?php elseif($item->seller_id == Auth::id()): ?>
                                                                <a href="<?php echo e(route('userTradeProfile',$item->buyer_id)); ?>"> <?php echo e($item->buyer->first_name.' '.$item->buyer->last_name); ?> </a>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php echo e(trade_order_status($item->status)); ?>

                                                        </td>

                                                        <td>
                                                            <a href="<?php echo e(route('tradeDetails', ($item->order_id))); ?>"><button class="btn deme-btn"><?php echo e(__('View')); ?></button></a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="7" class="text-center"><?php echo e(__('No data available')); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                            </tbody>
                                        </table>
                                        <?php if(isset($items[0])): ?>
                                            <div class="pull-right address-pagin">
                                                <?php echo e($items->appends(request()->input())->links()); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master',[ 'menu'=>'trade'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/p2p-exchange-web/resources/views/user/marketplace/market/trade_list.blade.php ENDPATH**/ ?>