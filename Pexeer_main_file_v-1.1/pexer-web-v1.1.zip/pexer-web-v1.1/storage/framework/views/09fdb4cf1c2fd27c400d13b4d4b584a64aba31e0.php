<?php $__env->startSection('title', isset($title) ? $title : __('Signup')); ?>

<?php $__env->startSection('content'); ?>
    <div class="user-content-wrapper">
        <div>
            <div class="user-form">
                <div class="right">
                    <div class="form-top">
                        <a class="auth-logo" href="javascript:;">
                            <img src="<?php echo e(show_image(1,'login_logo')); ?>" class="img-fluid" alt="">
                        </a>
                        <p><?php echo e(__('Sign up your account')); ?></p>
                    </div>
                    <?php echo e(Form::open(['route' => 'signUpProcess', 'files' => true])); ?>

                        <div class="form-group">
                            <label><?php echo e(__('First Name')); ?><span class="text-danger">*</span></label>
                            <input type="text" name="first_name" value="<?php echo e(old('first_name')); ?>" class="form-control" placeholder="<?php echo e(__('Your first name here')); ?>">
                            <?php if($errors->has('first_name')): ?>
                                <p class="invalid-feedback"><?php echo e($errors->first('first_name')); ?> </p>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('Last Name')); ?><span class="text-danger">*</span></label>
                            <input type="text" name="last_name" value="<?php echo e(old('last_name')); ?>" class="form-control" placeholder="<?php echo e(__('Your last name here')); ?>">
                            <?php if($errors->has('last_name')): ?>
                                <p class="invalid-feedback"><?php echo e($errors->first('last_name')); ?> </p>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('Email Address')); ?><span class="text-danger">*</span></label>
                            <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="<?php echo e(__('Your email here')); ?>">
                            <?php if($errors->has('email')): ?>
                                <p class="invalid-feedback"><?php echo e($errors->first('email')); ?> </p>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('Password')); ?><span class="text-danger">*</span></label>
                            <input type="password" name="password" class="form-control form-control-password look-pass" placeholder="<?php echo e(__('Your password here')); ?>">
                            <?php if($errors->has('password')): ?>
                                <p class="invalid-feedback"><?php echo e($errors->first('password')); ?> </p>
                            <?php endif; ?>
                            <span class="eye rev"><i class="fa fa-eye-slash toggle-password"></i></span>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('Confirm Password')); ?><span class="text-danger">*</span></label>
                            <input type="password" name="password_confirmation" class="form-control form-control-password look-pass-1" placeholder="<?php echo e(__('Your confirm password here')); ?>">
                            <?php if($errors->has('password_confirmation')): ?>
                                <p class="invalid-feedback"><?php echo e($errors->first('password_confirmation')); ?> </p>
                            <?php endif; ?>
                            <span class="eye rev-1"><i class="fa fa-eye-slash toggle-password"></i></span>
                        </div>
                        <?php if( app('request')->input('ref_code')): ?>
                                <?php echo e(Form::hidden('ref_code', app('request')->input('ref_code') )); ?>

                        <?php endif; ?>
                        <button type="submit" class="btn btn-primary nimmu-user-sibmit-button"><?php echo e(__('Signup')); ?></button>
                    <?php echo e(Form::close()); ?>

                    <div class="form-bottom text-center">
                        <p><?php echo e(__('Already have an account ?')); ?> <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Return to Sign In')); ?></a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    (function($) {
        "use strict";

        $(".toggle-password").on('click', function () {
            $(this).toggleClass("fa-eye-slash fa-eye");
        });
        $(".rev").on('click', function () {
            var $pwd = $(".look-pass");
            if ($pwd.attr('type') === 'password') {
                $pwd.attr('type', 'text');
            } else {
                $pwd.attr('type', 'password');
            }
        });

        $(".rev-1").on('click', function () {
            var $pwd = $(".look-pass-1");
            if ($pwd.attr('type') === 'password') {
                $pwd.attr('type', 'text');
            } else {
                $pwd.attr('type', 'password');
            }
        });
    })(jQuery);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.master',['menu'=>'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/p2p-exchange-web/resources/views/auth/signup.blade.php ENDPATH**/ ?>