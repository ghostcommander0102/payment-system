<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12 mb-xl-0 mb-4">
            <div class="card cp-user-custom-card">
                <div class="card-body">
                    <div class="cp-user-buy-coin-content-area">
                        <div class="cp-user-coin-info">
                            <div class="row mt-4">
                                <div class="col-sm-12">
                                    <div class="cp-user-card-header-area">
                                        <div class="title">
                                            <h4 id="list_title2"><a href="<?php echo e(route('marketPlace')); ?>"><?php echo e(__(' My Trades ')); ?></a> -> <?php echo e($type_text); ?>

                                                <?php if($type == 'seller'): ?>
                                                    <a href="<?php echo e(route('userTradeProfile',$item->buyer_id)); ?>"><?php echo e($item->buyer->first_name.' '.$item->buyer->last_name); ?></a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('userTradeProfile',$item->seller_id)); ?>"><?php echo e($item->seller->first_name.' '.$item->seller->last_name); ?></a>
                                                <?php endif; ?>
                                            </h4>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-5">
                                            <div class="cp-user-card-header-area">
                                                <div class="title">
                                                    <h4 id="list_title2"><?php echo e(__('Conversation')); ?></h4>
                                                    <h4 id="list_title2"><?php echo e(__('Messages are end-to-end encrypted.')); ?></h4>
                                                </div>
                                            </div>
                                                <p class="mt-2">
                                                    <span class=""><?php echo e(__('Say hello and exchange payment details with the other user. ')); ?></span>
                                                    <span class="text-warning"><b><?php echo e(__(' Remember:')); ?></b></span>
                                                    <span>
                                                        <ul>
                                                            <?php if($type == 'seller'): ?>
                                                            <li><?php echo e(__('Escrow should be released on the spot during the in-person exchange.')); ?></li>
                                                            <?php else: ?>
                                                                <li><?php echo e(__('Escrow should be released on the spot during the in-person exchange. Don\'t leave until the escrow is released.')); ?></li>
                                                            <?php endif; ?>
                                                            <li><?php echo e(__('Always use escrow. It\'s there for your safety.')); ?></li>
                                                            <li><?php echo e(__('Open a payment dispute if you run into trouble.')); ?></li>
                                                        </ul>
                                                    </span>
                                                </p>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="messages-box-right">
                                                        <?php if(isset($selected_user)): ?>
                                                            <div class="online-active">
                                                                <div class="row">
                                                                    <div class="col-sm-12">
                                                                        <div class="user-area">
                                                                            <div class="user-img">
                                                                                <a href="#"><img src="<?php echo e(show_image($selected_user->id,'user')); ?>"  alt="">
                                                                                </a>
                                                                            </div>
                                                                            <div class="user-name">
                                                                                <h5><a href="#"><?php echo e($selected_user->first_name.' '.$selected_user->last_name); ?></a></h5>
                                                                                <?php if($selected_user->isOnline()): ?> <span><?php echo e(__('Active Now')); ?></span> <?php endif; ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                        <div class="messages-box">
                                                            <div class="inner-message">
                                                                <?php if(!empty($chat_list)): ?>
                                                                    <ul id="messageData">
                                                                        <?php $__currentLoopData = $chat_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <li class="<?php echo e(($text->sender_id == Auth::user()->id) ? 'message-sent' : 'messages-resived'); ?> single-message">
                                                                                <?php if($text->sender_id == Auth::user()->id): ?>
                                                                                    <div class="msg">
                                                                                        <p><?php echo e($text->message); ?> </p>
                                                                                    </div>
                                                                                <?php endif; ?>
                                                                                <div class="user-img">
                                                                                    <img
                                                                                        <?php if(isset($text->sender_id)): ?>
                                                                                        src="<?php echo e(show_image($text->sender_id,'user')); ?>"
                                                                                        <?php endif; ?>

                                                                                        <?php if(isset($text->receiver_id)): ?>
                                                                                        src="<?php echo e(show_image($text->receiver_id,'user')); ?>"
                                                                                        <?php endif; ?>  alt="">
                                                                                </div>
                                                                                <?php if($text->receiver_id == Auth::user()->id): ?>
                                                                                    <div class="msg">
                                                                                        <p><?php echo e($text->message); ?>  </p>
                                                                                    </div>
                                                                                <?php endif; ?>
                                                                            </li>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </ul>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <?php if(isset($selected_user)): ?>
                                                            <div class="text-messages-area">
                                                                <Form id ="idForm">
                                                                    <div class="alert alert-danger myalert" id="notification_box" style="display:none"></div>
                                                                    <div class="text-messages-inner">
                                                                        <div class="form-group">
                                                                            <input type="hidden" id="receiverId" name="receiver_id" <?php if(isset($selected_user)): ?> value="<?php echo e(encrypt($selected_user->id)); ?>" <?php endif; ?>>
                                                                            <textarea required name="message" id="textMessage"><?php echo e(old('message')); ?></textarea>
                                                                        </div>
                                                                        <div class="send-btn">
                                                                            <button type="submit" id="submitButton" class="send"><?php echo e(__('Send')); ?></button>
                                                                        </div>
                                                                    </div>
                                                                </Form>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-7">
                                            <div class="row align-items-end">
                                                <div class="col-md-6">
                                                    <div class="cp-user-card-header-area">
                                                        <div class="title">
                                                            <h4 id="list_title2"><?php echo e(__('You are the ')); ?><?php echo e($type == 'buyer' ? __('Buyer') : __('Seller')); ?></h4>
                                                            <h4 id="list_title2"><?php echo e(__('Order id :  ')); ?> <?php echo e($item->order_id); ?></h4>
                                                            <?php if($item->status == TRADE_STATUS_TRANSFER_DONE): ?>
                                                                <h4 id="list_title2"><?php echo e(__('Transaction id :  ')); ?> <?php echo e($item->transaction_id); ?></h4>
                                                            <?php endif; ?>
                                                            <h4 id="list_title2"><?php echo e(__('Selected payment method is :  ')); ?>

                                                                <span><img src="<?php echo e($item->payment_method->image); ?>" alt=""></span>
                                                                <?php echo e($item->payment_method->name); ?>

                                                            </h4>
                                                            <?php if($item->status != TRADE_STATUS_TRANSFER_DONE): ?>
                                                                <h4 id="list_title2"><?php echo e(__('Waiting for the ')); ?><?php echo e($type == 'seller' ? __('Buyer') : __('Seller')); ?></h4>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <?php if(!empty($item->payment_sleep)): ?>
                                                        <div class="view-payment-receipt">
                                                            <Button class="btn theme-btn" data-target="#view-payment-receipt" data-toggle="modal"><?php echo e(__('View Payment Receipt')); ?></Button>
                                                        </div>
                                                        <div id="view-payment-receipt" class="modal fade view-payment-receipt-modal" role="dialog">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header"><h6 class="modal-title"><?php echo e(__('Payment Receipt')); ?></h6><button type="button" class="close" data-dismiss="modal">&times;</button></div>

                                                                    <div class="modal-body">
                                                                        <?php if(!empty($item->payment_sleep)): ?>
                                                                            <img src="<?php echo e(asset(path_image().$item->payment_sleep)); ?>" alt="">
                                                                        <?php else: ?>
                                                                            <p><?php echo e(__('Payment slip not found')); ?></p>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="alert alert-info" role="alert">
                                                <?php if($type == 'buyer'): ?>
                                                    <?php echo e(__('Don’t pay the seller until they put ')); ?> <?php echo e($item->coin_type); ?> <?php echo e(__(' in escrow. Once escrowed, this status will change.')); ?>

                                                <?php else: ?>
                                                    <?php echo e(__('Before accepting payment, you must put the ')); ?> <?php echo e($item->coin_type); ?> <?php echo e(__(' into a secure escrow account.')); ?>

                                                <?php endif; ?>
                                            </div>

                                            <div class="row no-gutters">
                                                <?php if($item->status == TRADE_STATUS_CANCEL): ?>
                                                    <div class="col-md-12">
                                                        <p class =" text-center font-weight-bold text-danger">
                                                            <?php echo e(__('Order Cancelled')); ?>

                                                        </p>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="col-md-4 col-lg-3">
                                                        <p class="trade-step step-complete">
                                                            <?php if(!empty($item->buy_id)): ?>
                                                                <?php echo e(__('Sell order placed')); ?>

                                                            <?php elseif(!empty($item->sell_id)): ?>
                                                                <?php echo e(__('Buy order placed')); ?>

                                                            <?php endif; ?>
                                                        </p>
                                                    </div>
                                                    <div class="col-md-4 col-lg-3">
                                                        <p class ="trade-step <?php if($item->status == TRADE_STATUS_ESCROW || $item->status == TRADE_STATUS_PAYMENT_DONE || $item->status == TRADE_STATUS_TRANSFER_DONE): ?> step-complete <?php endif; ?>">
                                                            <?php echo e(__('Seller puts ')); ?> <?php echo e($item->coin_type); ?> <?php echo e(__(' in escrow')); ?>

                                                        </p>
                                                    </div>
                                                    <div class="col-md-4 col-lg-3">
                                                        <p class ="trade-step <?php if($item->status == TRADE_STATUS_PAYMENT_DONE || $item->status == TRADE_STATUS_TRANSFER_DONE): ?> step-complete <?php endif; ?>">
                                                            <?php echo e(__('Buyer pays seller directly')); ?>

                                                        </p>
                                                    </div>
                                                    <div class="col-md-4 col-lg-3">
                                                        <p class ="trade-step <?php if($item->status == TRADE_STATUS_TRANSFER_DONE): ?> step-complete <?php endif; ?>">
                                                            <?php echo e(__('Escrow released to buyer')); ?>

                                                        </p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>

                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="cp-user-card-header-area">
                                                        <div class="title">
                                                            <h4 id="list_title2"><?php echo e($type == 'seller' ? __('Selling') : __('Buying')); ?></h4>
                                                            <h4 id="list_title2"><?php echo e(number_format(($item->amount),8).' '.$item->coin_type); ?></h4>
                                                            <h4 id="list_title2"><?php echo e(__('for')); ?></h4>
                                                            <h4 id="list_title2"><?php echo e($item->currency .' '.number_format($item->price,8)); ?></h4>
                                                            <h4 id="list_title2">1 <?php echo e($item->coin_type .' = '.$item->currency .' '.number_format($item->rate,8)); ?></h4>
                                                            <h4 id="list_title2"> <?php echo e(__('Fees') .' = '.number_format($item->fees,8).' '.$item->coin_type); ?></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <?php if($item->status == TRADE_STATUS_TRANSFER_DONE): ?>
                                                        <div class="cp-user-card-header-area">
                                                            <div class="title">
                                                                <h4 id="list_title2"><?php echo e(__('Transaction Successful')); ?></h4>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if($item->is_reported == STATUS_ACTIVE): ?>
                                                        <?php if(isset($report)): ?>
                                                            <div class="cp-user-card-header-area">
                                                                <div class="title">
                                                                    <h4 id="list_title2" class="text-danger">
                                                                        <?php if($report->type == BUYER): ?> <?php echo e(__('The buyer ')); ?> <?php else: ?> <?php echo e(__('The seller ')); ?> <?php endif; ?> <?php echo e(__(' reported against order.')); ?>

                                                                    </h4>
                                                                    <?php if(!empty($item->transaction_id)): ?>
                                                                        <h5 class="text-warning"><?php echo e($item->transaction_id); ?></h5>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <ul class="d-flex">
                                                    <?php if($type == 'seller'): ?>
                                                        <?php if($item->status == TRADE_STATUS_INTERESTED): ?>
                                                            <li class="deleteuser mr-3">
                                                                <a title="<?php echo e(__('Fund Escrow')); ?>" href="#escrow_<?php echo e(($item->id)); ?>" data-toggle="modal">
                                                                    <button class="btn theme-btn"><?php echo e(__('Fund Escrow')); ?></button>
                                                                </a>
                                                            </li>
                                                            <div id="escrow_<?php echo e(($item->id)); ?>" class="modal fade delete" role="dialog">
                                                                <div class="modal-dialog modal-md">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header"><h6 class="modal-title"><?php echo e(__('Escrow')); ?></h6><button type="button" class="close" data-dismiss="modal">&times;</button></div>
                                                                        <?php if(isset($check_balance)): ?>
                                                                        <div class="modal-body">
                                                                            <p><?php echo e(__('Do you want to escrow ?')); ?></p>
                                                                            <?php if($check_balance['success'] == false): ?>
                                                                                <p class="text-danger"><?php echo e($check_balance['message']); ?></p>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                        <div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__("Close")); ?></button>
                                                                            <?php if($check_balance['success'] == true): ?>
                                                                                <a class="btn btn-danger" href="<?php echo e(route('fundEscrow', encrypt($item->id))); ?>"><?php echo e(__('Confirm')); ?></a>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                        <?php if($item->status == TRADE_STATUS_PAYMENT_DONE): ?>
                                                            <li class="deleteuser mr-3">
                                                                <a title="<?php echo e(__('Release Escrow')); ?>" href="#escrow_<?php echo e(($item->id)); ?>" data-toggle="modal">
                                                                    <button class="btn theme-btn"><?php echo e(__('Release Escrow')); ?></button>
                                                                </a>
                                                            </li>
                                                            <div id="escrow_<?php echo e(($item->id)); ?>" class="modal fade delete" role="dialog">
                                                                <div class="modal-dialog modal-md">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header"><h6 class="modal-title"><?php echo e(__('Release Escrow')); ?></h6><button type="button" class="close" data-dismiss="modal">&times;</button></div>
                                                                        <div class="modal-body"><p><?php echo e(__('Do you want to release escrow ?')); ?></p></div>
                                                                        <div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__("Close")); ?></button>
                                                                            <a class="btn btn-danger" href="<?php echo e(route('releasedEscrow', encrypt($item->id))); ?>"><?php echo e(__('Confirm')); ?></a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                        <?php if($item->status == TRADE_STATUS_INTERESTED || $item->status == TRADE_STATUS_ESCROW): ?>
                                                            <li class="deleteuser mr-3">
                                                                <a title="<?php echo e(__('Cancel Trade')); ?>" href="#cancel_<?php echo e(($item->id)); ?>" data-toggle="modal">
                                                                    <button class="btn theme-btn"><?php echo e(__('Cancel Trade')); ?></button>
                                                                </a>
                                                            </li>
                                                            <div id="cancel_<?php echo e(($item->id)); ?>" class="modal fade delete" role="dialog">
                                                                <div class="modal-dialog modal-md">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header"><h6 class="modal-title"><?php echo e(__('Cancel')); ?></h6><button type="button" class="close" data-dismiss="modal">&times;</button></div>
                                                                        <div class="modal-body">
                                                                            <p><?php echo e(__('Do you want to cancel order ?')); ?></p>
                                                                            <form action="<?php echo e(route('tradeCancel')); ?>" method="POST" enctype="multipart/form-data"
                                                                                  id="">
                                                                                <?php echo csrf_field(); ?>
                                                                                <input type="hidden" name="order_id" value="<?php echo e(encrypt($item->id)); ?>">
                                                                                <input type="hidden" name="type" value="<?php echo e(SELLER); ?>">
                                                                                <div class="cp-user-payment-type">
                                                                                    <h3><?php echo e(__('Reason')); ?> </h3>
                                                                                    <textarea name="reason" required class="form-control"></textarea>
                                                                                </div>
                                                                                <button type="submit" class=" mt-4 btn theme-btn"><?php echo e(__('Submit')); ?></button>
                                                                            </form>
                                                                        </div>
                                                                        <div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__("Close")); ?></button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php if($type == 'buyer'): ?>
                                                        <?php if($item->status == TRADE_STATUS_INTERESTED): ?>
                                                            <li class="deleteuser mr-3">
                                                                <a title="<?php echo e(__('Cancel Trade')); ?>" href="#cancel_<?php echo e(($item->id)); ?>" data-toggle="modal">
                                                                    <button class="btn theme-btn"><?php echo e(__('Cancel Trade')); ?></button>
                                                                </a>
                                                            </li>
                                                            <div id="cancel_<?php echo e(($item->id)); ?>" class="modal fade delete" role="dialog">
                                                                <div class="modal-dialog modal-md">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header"><h6 class="modal-title"><?php echo e(__('Cancel')); ?></h6><button type="button" class="close" data-dismiss="modal">&times;</button></div>
                                                                        <div class="modal-body">
                                                                            <p><?php echo e(__('Do you want to cancel order ?')); ?></p>
                                                                            <form action="<?php echo e(route('tradeCancel')); ?>" method="POST" enctype="multipart/form-data"
                                                                                  id="">
                                                                                <?php echo csrf_field(); ?>
                                                                                <input type="hidden" name="order_id" value="<?php echo e(encrypt($item->id)); ?>">
                                                                                <input type="hidden" name="type" value="<?php echo e(BUYER); ?>">
                                                                                <div class="cp-user-payment-type">
                                                                                    <h3><?php echo e(__('Reason')); ?> </h3>
                                                                                    <textarea name="reason" required class="form-control"></textarea>
                                                                                </div>
                                                                                <button type="submit" class=" mt-4 btn theme-btn"><?php echo e(__('Submit')); ?></button>
                                                                            </form>
                                                                        </div>
                                                                        <div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__("Close")); ?></button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                        <?php if($item->status == TRADE_STATUS_ESCROW): ?>
                                                            <li class="deleteuser mr-3">
                                                                <a title="<?php echo e(__('Upload Payment Slip')); ?>" href="#upload_<?php echo e(($item->id)); ?>" data-toggle="modal">
                                                                    <button class="btn theme-btn"><?php echo e(__('Upload Payment Slip')); ?></button>
                                                                </a>
                                                            </li>
                                                            <div id="upload_<?php echo e(($item->id)); ?>" class="modal fade delete" role="dialog">
                                                                <div class="modal-dialog modal-md">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header"><h6 class="modal-title"><?php echo e(__('Upload Payment Slip')); ?></h6><button type="button" class="close" data-dismiss="modal">&times;</button></div>
                                                                        <div class="modal-body">
                                                                            <p><?php echo e(__('If your payment has done then upload your Payment Slip')); ?></p>
                                                                            <form action="<?php echo e(route('uploadPaymentSleep')); ?>" method="POST" enctype="multipart/form-data"
                                                                                  id="">
                                                                                <?php echo csrf_field(); ?>
                                                                                <input type="hidden" name="order_id" value="<?php echo e(encrypt($item->id)); ?>">
                                                                                <div class="cp-user-payment-type">
                                                                                    <h3><?php echo e(__('Payment Slip ')); ?> </h3>
                                                                                    <div id="file-upload" class="section-p">
                                                                                        <input type="file" placeholder="0.00" required name="payment_sleep" value=""
                                                                                            id="file" ref="file" class="dropify" />
                                                                                    </div>
                                                                                </div>

                                                                                <button type="submit" class=" mt-4 btn theme-btn"><?php echo e(__('Upload')); ?></button>
                                                                            </form>
                                                                        </div>
                                                                        <div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__("Close")); ?></button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php if($item->status != TRADE_STATUS_TRANSFER_DONE): ?>
                                                        <li class="deleteuser mr-3">
                                                            <a title="<?php echo e(__('Report User')); ?>" href="#report_<?php echo e(($item->id)); ?>" data-toggle="modal">
                                                                <button class="btn theme-btn"><?php echo e(__('Report User')); ?></button>
                                                            </a>
                                                        </li>
                                                        <div id="report_<?php echo e(($item->id)); ?>" class="modal fade delete" role="dialog">
                                                            <div class="modal-dialog modal-md">
                                                                <div class="modal-content">
                                                                    <div class="modal-header"><h6 class="modal-title"><?php echo e(__('Report User')); ?></h6><button type="button" class="close" data-dismiss="modal">&times;</button></div>
                                                                    <div class="modal-body">
                                                                        <p><?php echo e(__('Do you want to report this order ?')); ?></p>
                                                                        <form action="<?php echo e(route('reportUserOrder')); ?>" method="POST" enctype="multipart/form-data"
                                                                              id="">
                                                                            <?php echo csrf_field(); ?>
                                                                            <input type="hidden" name="order_id" value="<?php echo e(encrypt($item->id)); ?>">
                                                                            <input type="hidden" name="type" <?php if($type =='seller'): ?> value="<?php echo e(SELLER); ?>" <?php else: ?> value="<?php echo e(BUYER); ?>" <?php endif; ?>>
                                                                            <div class="cp-user-payment-type">
                                                                                <h3><?php echo e(__('Reason')); ?> </h3>
                                                                                <textarea name="reason"  class="form-control"></textarea>
                                                                            </div>
                                                                            <div class="cp-user-payment-type mt-3">
                                                                                <h3><?php echo e(__('Attachment (if any) ')); ?> </h3>
                                                                                <div id="file-upload" class="section-p">
                                                                                    <input type="file" placeholder="0.00"  name="attach_file" value=""
                                                                                        id="file" ref="file" class="dropify" />
                                                                                </div>
                                                                            </div>
                                                                            <button type="submit" class=" mt-4 btn theme-btn"><?php echo e(__('Submit')); ?></button>
                                                                        </form>
                                                                    </div>
                                                                    <div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__("Close")); ?></button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                    </ul>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row mt-5">
                                                <div class="col-xl-4">
                                                    <div class="cp-user-card-header-area">
                                                        <div class="title">
                                                            <h4 id="list_title2"><?php echo e(__('About the ')); ?><?php echo e($type == 'seller' ? __('Buyer') : __('Seller')); ?></h4>
                                                        </div>
                                                    </div>
                                                    <ul class="seller-info">
                                                        <li>
                                                            <?php if($type == 'seller'): ?>
                                                                <a href="<?php echo e(route('userTradeProfile',$item->buyer_id)); ?>"><?php echo e($item->buyer->first_name.' '.$item->buyer->last_name); ?></a>
                                                            <?php else: ?>
                                                                <a href="<?php echo e(route('userTradeProfile',$item->seller_id)); ?>"><?php echo e($item->seller->first_name.' '.$item->seller->last_name); ?></a>
                                                            <?php endif; ?>
                                                        </li>
                                                        <li><?php echo e(__('100% good feedback')); ?></li>
                                                        <li><?php echo e(__('Registered ')); ?>

                                                            <?php if($type == 'seller'): ?>
                                                                 <?php echo e(date('M Y', strtotime($item->buyer->created_at))); ?>

                                                            <?php else: ?>
                                                                <?php echo e(date('M Y', strtotime($item->seller->created_at))); ?>

                                                            <?php endif; ?>
                                                        </li>
                                                        <li>
                                                            <?php if($type == 'seller'): ?>
                                                                <?php echo e(count_trades($item->buyer_id)); ?> <?php echo e(__(' trades')); ?>

                                                            <?php else: ?>
                                                                <?php echo e(count_trades($item->seller_id)); ?> <?php echo e(__(' trades')); ?>

                                                            <?php endif; ?>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="col-xl-8">
                                                    <div class="cp-user-card-header-area">
                                                        <div class="title">
                                                            <h4 id="list_title2"><?php echo e(__('Headline ')); ?></h4>
                                                            <?php if(!empty($item->buy_id)): ?>
                                                                <b><?php echo e($item->buy_data->headline); ?></b>
                                                            <?php elseif(!empty($item->sell_id)): ?>
                                                                <b><?php echo e($item->sell_data->headline); ?></b>
                                                            <?php else: ?>
                                                                <p>'.....................................'</p>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="cp-user-card-header-area">
                                                        <div class="title">
                                                            <h4 id="list_title2"><?php echo e(__('Terms and Condition ')); ?></h4>
                                                            <?php if(!empty($item->buy_id)): ?>
                                                                <p><?php echo e($item->buy_data->terms); ?></p>
                                                            <?php elseif(!empty($item->sell_id)): ?>
                                                                <p><?php echo e($item->sell_data->terms); ?></p>
                                                            <?php else: ?>
                                                                <p>'.....................................'</p>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="cp-user-card-header-area">
                                                        <div class="title">
                                                            <h4 id="list_title2"><?php echo e(__('Trading Instruction')); ?></h4>
                                                            <?php if(!empty($item->buy_id)): ?>
                                                                <p><?php echo e($item->buy_data->instruction); ?></p>
                                                            <?php elseif(!empty($item->sell_id)): ?>
                                                                <p><?php echo e($item->sell_data->instruction); ?></p>
                                                            <?php else: ?>
                                                                <p>'.....................................'</p>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        (function($) {
            "use strict";

            jQuery(document).ready(function(){
                Pusher.logToConsole = true;

                Echo.channel('userordermessage_' + '<?php echo e(Auth::id()); ?>'+'_'+'<?php echo e($item->id); ?>')
                    .listen('.receive_message', (data) => {
                        console.log(data);
                        var message = data.data.message;
                        var image = data.data.sender_user.image;

                        $("#messageData").append('<li class="messages-resived single-message">' +
                            '<div class="user-img"> <img src="'+image+'"> </div>' +
                            '<div class="msg">' + '<p>'+message+'</p>' + '</div></li>');
                    });

                $('form#idForm').on('submit', function (e) {
                    e.preventDefault();

                    var receiverId = $('#receiverId').val();
                    var textMessage = $('#textMessage').val();

                    sendMessage(receiverId,textMessage);
                    $("#idForm")[0].reset();
                });

                function sendMessage(receiverId,textMessage) {
                    $.ajax({
                        type: "POST",
                        url: '<?php echo e(route('sendOrderMessage')); ?>',
                        data: {
                            '_token' : '<?php echo e(csrf_token()); ?>',
                            'receiver_id' : receiverId,
                            'message' : textMessage,
                            'order_id' : '<?php echo e($item->id); ?>',
                        },
                        success: function(data){
                            var message = data.data.data.message;
                            var myImage = data.data.data.my_image;

                            console.log(myImage);
                            $("#messageData").append('<li class="message-sent single-message">' +
                                '<div class="msg">' + '<p>'+message+'</p>' + '</div>'+
                                '<div class="user-img"> <img src="'+myImage+'"> </div></li>');
                        }
                    });
                }
            });

        })(jQuery);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master',[ 'menu'=>'trade'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/p2p-exchange-web/resources/views/user/marketplace/market/order_details.blade.php ENDPATH**/ ?>