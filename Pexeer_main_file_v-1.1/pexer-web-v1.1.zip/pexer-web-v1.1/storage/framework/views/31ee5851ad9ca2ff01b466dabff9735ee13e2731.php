<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:type" content="article"/>
    <meta property="og:title" content="<?php echo e(allsetting('app_title')); ?>"/>
    <meta property="og:image" content="<?php echo e(show_image(1,'logo')); ?>">
    <meta property="og:site_name" content="<?php echo e(allsetting('app_title')); ?>"/>
    <meta property="og:url" content="<?php echo e(url()->current()); ?>"/>
    <meta itemprop="image" content="<?php echo e(show_image(1,'logo')); ?>"/>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/bootstrap.min.css')); ?>">
    <!-- metismenu CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/metisMenu.min.css')); ?>">
    <!-- fontawesome CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/icofont.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/owl.theme.default.min.css')); ?>">
    
    <link href="<?php echo e(asset('assets/common/toast/vanillatoasts.css')); ?>" rel="stylesheet">
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/landing/style.css')); ?>">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/landing/css/responsive.css')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> </title>
    <!-- Favicon and Touch Icons -->
    <link rel="shortcut icon" href="<?php echo e(landingPageImage('favicon','images/Pexeer.svg')); ?>/">
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body class="body-bg" id="top"  data-spy="is_sticky">

<!-- header start-->
<header>
    <div class="header-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-sm-6 col-6 order-lg-0 order-1">
                    <div class="header-actions text-left">
                        <a href="<?php echo e(route('marketPlace')); ?>" class="btn cbtn1"><?php echo e(__('Exchange')); ?></a>
                    </div>
                </div>
                <div class="col-lg-4 col-12 order-lg-0 order-0 mb-lg-0 mb-4 d-lg-block d-none">
                    <div class="logo">
                        <a href="<?php echo e(route('home')); ?>">
                            <img src="<?php echo e(show_image(1,'logo')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 col-6 order-lg-0 order-2">
                    <div class="header-actions">
                        <a href="<?php echo e(route('login')); ?>" class="btn cbtn1"><?php echo e(__('Sign in')); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- header end-->

<?php echo $__env->yieldContent('content'); ?>


<footer class="footer">
    <div class="container">
        <div class="top-footer">
            <div class="row">
                <div class="col-lg-2 col-md-5 col-sm-6 order-lg-0 order-0 mb-lg-0 mb-5">
                    <div class="footer-widget">
                        <a href="#top" class="ftr-logo">
                            <img src="<?php echo e(show_image(1,'logo')); ?>" class="img-fluid" alt="">
                        </a>
                        <ul class="social-links">
                            <li><a href="void:"><i class="icofont-behance"></i></a></li>
                            <li><a href="void:"><i class="icofont-dribbble"></i></a></li>
                            <li><a href="void:"><i class="icofont-twitter"></i></a></li>
                            <li><a href="void:"><i class="icofont-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 order-lg-0 order-2 mb-sm-0 mb-5">
                    <div class="footer-widget">
                        <p class="title"><?php echo e(__('About')); ?></p>
                        <p>
                            <?php if(isset($settings['about_section_des'])): ?>
                                <?php echo clean(\Illuminate\Support\Str::limit($settings['about_section_des'],150)); ?>

                                <?php else: ?> Aenean condimentum nibh vel enim sodales scelerisque. Mauris quisn pellentesque odio, in vulputate turpis. Integer condimentum eni lorem pellentesque euismod. Nam rutrum accumsan nisl vulputate.
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-6 order-lg-0 order-3 mb-sm-0 mb-5">
                    <div class="footer-widget">
                        <p class="title"><?php echo e(__('Features')); ?></p>
                        <ul class="links">
                            <?php if(isset($pexer_features[0])): ?>
                                <?php $__currentLoopData = $pexer_features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e(explode('|',$feature->slug)[1]); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <li>Various Ways To Pay</li>
                                <li>No Middleman</li>
                                <li>Worldwide Service</li>
                                <li>Encrypted Message</li>
                                <li>Fast Service</li>
                                <li>Non-custodial</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 order-lg-0 order-1 mb-lg-0 mb-5">
                    <div class="footer-widget address-widget">
                        <p class="title"><?php echo e(__('Contacts')); ?></p>
                        <p><?php if(isset($settings['company_address'])): ?> <?php echo clean($settings['company_address']); ?>  <?php else: ?> 5055 North 03th Avenue,Penscola, FL 32503, New York <?php endif; ?></p>
                        <ul class="content-links">
                            <li><i class="icofont-phone"></i><?php if(isset($settings['company_mobile_no'])): ?> <?php echo clean($settings['company_mobile_no']); ?> <?php else: ?> +1 965 047 658 23 <?php endif; ?></li>
                            <li><i class="icofont-envelope"></i> <?php if(isset($settings['company_email_address'])): ?> <?php echo clean($settings['company_email_address']); ?> <?php else: ?> pexeercom54@gmail.com <?php endif; ?></li>
                        </ul>
                    </div>
                </div>
            </div>

        </div>
        <div class="bottom-footer">
            <p><?php echo clean($settings['copyright_text']); ?></p>
        </div>
    </div>
</footer>


<!-- js file start -->

<!-- JavaScript -->
<script src="<?php echo e(asset('assets/common/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/metisMenu.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/common/toast/vanillatoasts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/sweetalert/sweetalert.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/anime.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/common/js/owl.carousel.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/landing/js/main.js')); ?>"></script>

<script>
    (function($) {
        "use strict";

        <?php if(session()->has('success')): ?>
            swal({
                text: '<?php echo e(session('success')); ?>',
                icon: "success",
                buttons: false,
                timer: 3000,
            });

        <?php elseif(session()->has('dismiss')): ?>
            swal({
                text: '<?php echo e(session('dismiss')); ?>',
                icon: "warning",
                buttons: false,
                timer: 3000,
            });

        <?php elseif($errors->any()): ?>
            <?php $__currentLoopData = $errors->getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                swal({
                    text: '<?php echo e($error[0]); ?>',
                    icon: "error",
                    buttons: false,
                    timer: 3000,
                });
                <?php break; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    })(jQuery);

</script>

<?php echo $__env->yieldContent('script'); ?>
<!-- End js file -->
</body>
</html>
<?php /**PATH /var/www/html/p2p-exchange-web/resources/views/landing/master.blade.php ENDPATH**/ ?>