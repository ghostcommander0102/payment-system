<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="custom-breadcrumb">
        <div class="row">
            <div class="col-12">
                <ul>
                    <li><?php echo e(__('Crypto Exchange')); ?></li>
                    <li class="active-item"><?php echo e($title); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- User Management -->
    <div class="user-management">
        <div class="row">
            <div class="col-12">
                <div class="profile-info-form">
                    <div class="card-body">
                        <form action="<?php echo e(route('paymentMethodSave')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12 mt-20">
                                    <div class="form-group">
                                        <label for="firstname"><?php echo e(__('Method Name')); ?></label>
                                        <input type="text" name="name" class="form-control" id="firstname" placeholder="<?php echo e(__('Payment method name')); ?>"
                                               <?php if(isset($item)): ?> value="<?php echo e($item->name); ?>" <?php else: ?> value="<?php echo e(old('name')); ?>" <?php endif; ?>>
                                        <span class="text-danger"><strong><?php echo e($errors->first('name')); ?></strong></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-20">
                                    <div class="form-group">
                                        <label><?php echo e(__('Select Country')); ?></label>
                                        <div class="cp-select-area">
                                            <select multiple name="country[]" class=" selectpicker form-control" id="select-payment-method" data-container="body" data-live-search="true" title="" data-hide-disabled="true" data-actions-box="true" data-virtual-scroll="false">
                                                <?php $__currentLoopData = countrylist(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if(isset($item) && in_array($key,$selected_country)): ?> selected <?php endif; ?>  value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-20">
                                    <div class="form-group">
                                        <label><?php echo e(__('Activation Status')); ?></label>
                                        <div class="cp-select-area">
                                            <select name="status" class="form-control wide" >
                                                <?php $__currentLoopData = status(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if(isset($item) && ($item->status == $key)): ?> selected
                                                            <?php elseif((old('status') != null) && (old('status') == $key)): ?> <?php endif; ?> value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                                    <span class="text-danger"><strong><?php echo e($errors->first('status')); ?></strong></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 mt-20">
                                    <div class="form-group">
                                        <label><?php echo e(__('Short Note (Optional)')); ?></label>
                                        <textarea name="details" id="" rows="2" class="form-control"><?php if(isset($item)): ?><?php echo e($item->details); ?><?php else: ?><?php echo e(old('details')); ?><?php endif; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-4 mt-20">
                                    <div class="single-uplode">
                                        <div class="uplode-catagory">
                                            <span><?php echo e(__('Payment logo')); ?></span>
                                        </div>
                                        <div class="form-group buy_coin_address_input ">
                                            <div id="file-upload" class="section-p">
                                                <input type="file" placeholder="0.00" name="image" value=""
                                                       id="file" ref="file" class="dropify"
                                                       <?php if(isset($item)): ?>  data-default-file="<?php echo e($item->image); ?>" <?php endif; ?> />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <?php if(isset($item)): ?>
                                        <input type="hidden" name="edit_id" value="<?php echo e($item->id); ?>">
                                    <?php endif; ?>
                                    <button class="button-primary theme-btn"><?php if(isset($item)): ?> <?php echo e(__('Update')); ?> <?php else: ?> <?php echo e(__('Create')); ?> <?php endif; ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /User Management -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master',['menu'=>'payment_method'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/p2p-exchange-web/resources/views/admin/marketplace/payment/addEdit.blade.php ENDPATH**/ ?>