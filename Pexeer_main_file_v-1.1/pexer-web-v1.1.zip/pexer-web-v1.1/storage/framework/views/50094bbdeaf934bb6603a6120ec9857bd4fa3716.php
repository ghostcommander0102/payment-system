<div class="btn-group dropdown">
    <button type="button" class="btn notification-btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <span class="notify-value hm-notify-number"><?php if(isset($notifications) && ($notifications ->count() > 0)): ?> <?php echo e($notifications->count()); ?> <?php else: ?> 0 <?php endif; ?></span>
        <img src="<?php echo e(asset('assets/img/icons/notification.png')); ?>" class="img-fluid" alt="">
    </button>
    <?php if(!empty($notifications)): ?>
        <div class="dropdown-menu notification-list dropdown-menu-right">
            <div class="text-center p-2 border-bottom nt-title"><?php echo e(__('New Notifications')); ?></div>
            <ul class="scrollbar-inner">
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="javascript:void(0);" data-toggle="modal" data-id="<?php echo e($item->id); ?>" data-target="#notificationShow" class="dropdown-item viewNotice">
                            <span class="small d-block"><?php echo e(date('d M y', strtotime($item->created_at))); ?></span>
                            <?php echo clean($item->title); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH /var/www/html/p2p-exchange-web/resources/views/user/notification_item.blade.php ENDPATH**/ ?>