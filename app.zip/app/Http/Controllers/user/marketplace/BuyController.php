<?php

namespace App\Http\Controllers\user\marketplace;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BuyController extends Controller
{

}
